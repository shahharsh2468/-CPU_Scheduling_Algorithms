<?php
    $count=1;
    $count2=0;
    $count3=0;
    $flag=0;
    $ATT=0;
    $AWT=0;
    $hold=0;
    $hold2=0;
    $hold3=0;
    $hold4=0;
        if(isset($_POST["submit"]))
        {
            $count=$_POST['count'];
        }
        if(isset($_POST["solve"]))
        {
            for($x=1;$x<=$count;$x++)
            {
             $count=$_POST['count'];
             $Process[$x][0]=$x;
             $sort[$x]=$x;
             $Process[$x][1]=$_POST['bt'.$x];
             $Process[$x][2]=$_POST['at'.$x];
             $flag=1;
            }
        }
?>
<form method="post" ><center>
Number of Process:<input type="text" name="count" id="count" placeholder="count" value="<?php echo $count; ?>"><br><br>
<input type="submit" id="submit" placeholder="submit" name="submit" value="Submit">
<br>

<br>
<br>
<?php
if($flag==1)
    {
    for($x=1;$x<$count;$x++)
    {
      $hold4=0;
     for($y=1;$y<$count;$y++)
     {
        if($hold4<=$Process[$y][2])
        {      
        $hold4=$Process[$y][2];
        }
        if($Process[$y+1][1]<$Process[$y][1] AND $hold4>=$Process[$y+1][2] AND $Process[$y][2]<=$Process[$y+1][2])
        {
            $temp2=$Process[$y][1];
            $Process[$y][1]=$Process[$y+1][1];
            $Process[$y+1][1]=$temp2;
            $temp1=$Process[$y][0];
            $Process[$y][0]=$Process[$y+1][0];
            $Process[$y+1][0]=$temp1;
            $temp3=$Process[$y][2];
            $Process[$y][2]=$Process[$y+1][2];
            $Process[$y+1][2]=$temp3;      
        }              
        $hold4=$hold4+$Process[$y][1];
     }
     }
     for($x=1;$x<=$count;$x++)
      {
        if($count2<=$Process[$x][2])
        {
            $count2=$Process[$x][2];
        }
        $hold=$count2+$Process[$x][1];
        for($y=$count2;$y<$hold;$y++)
         {
            $count2++;
         }
         $Process[$x][3]=$count2;
         $Process[$x][4]=$Process[$x][3]-$Process[$x][2];
         $Process[$x][5]=$Process[$x][4]-$Process[$x][1];
         $ATT=$ATT+$Process[$x][4];
         $AWT=$AWT+$Process[$x][5];
      }    
    $ATT=$ATT/$count;
    $AWT=$AWT/$count;
    $Process[0][3]=0;
    for($x=1;$x<=$count;$x++)
    {
?>
Process:<?php echo $Process[$x][0]; ?> :
<?php
          for($y=1;$y<=$Process[$x][3];$y++)
           {
              if($Process[$x][2]>$Process[$x-1][3])
              {
                $hold2=$Process[$x][2];
              }
              else
              {
                $hold2=$Process[$x-1][3];
              }
              if(($y>$hold2 AND $x!=1) OR $x==1)
              {
?>
        <font style="background-color:#62<?php echo $x;?>4<?php echo $x;?>5" color="#62<?php echo $x;?>4<?php echo $x;?>5" > <?php echo $x;?> </font>
<?php } else { ?>
        <font style="background-color:#FFFFFF" color="#FFFFFF"><?php echo $x;?></font>
<?php
    }
}
?>
<br>
<?php
    }
?>
<br>
<br>
Average Turnaround Time: <?php echo $ATT; ?> <br>
Average Waiting Time: <?php echo $AWT; ?> <br>  

 <table border="0">
        <tr>
            <th>ProcessID</th>
            <th>Burst Time</th>
            <th>Arrival Time</th>
            <th>Finish Time</th>
            <th>Turnaround Time</th>
            <th>Waiting Time</th>
        </tr>
        <?php
        for($x=1;$x<=$count;$x++)
        {
        ?>
        <tr>
        <th><?php echo $Process[$x][0]; ?></th>
        <th><?php echo $Process[$x][1]; ?></th>
        <th><?php echo $Process[$x][2]; ?></th>
        <th><?php echo $Process[$x][3]; ?></th>
        <th><?php echo $Process[$x][4]; ?></th>
        <th><?php echo $Process[$x][5]; ?></th>
        </tr>
 <?php }} else { ?>
 <table border="0">
        <tr>
            <th>ProcessID</th>
            <th>Arrival Time</th>
            <th>Burst Time</th>
        </tr>
        <?php
        for($x=1;$x<=$count;$x++)
        {
        ?>
        <tr>
        <th><?php echo $x ?></th>
        <th><input type="text" id="at<?php echo $x; ?>" name="at<?php echo $x; ?>" placeholder="at<?php echo $x; ?>"></th>
        <th><input type="text" id="bt<?php echo $x; ?>" name="bt<?php echo $x; ?>" placeholder="bt<?php echo $x; ?>"></th>
        </tr>
 <?php }} ?>
 </table>
 <input type="submit" name="solve" id="solve" placeholder="solve" value="Solve">
 </center>
</form>